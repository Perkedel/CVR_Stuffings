namespace UnityEditor.Graphing
{
    interface IOnAssetEnabled
    {
        void OnEnable();
    }
}
