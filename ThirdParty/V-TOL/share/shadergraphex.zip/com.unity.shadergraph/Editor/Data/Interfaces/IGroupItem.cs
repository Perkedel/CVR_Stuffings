using System;

namespace UnityEditor.ShaderGraph
{
    interface IGroupItem
    {
        Guid groupGuid { get; set; }
    }
}
