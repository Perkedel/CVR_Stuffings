using System;

namespace UnityEditor.ShaderGraph
{
    enum NormalMapSpace
    {
        Tangent,
        Object
    }
}
