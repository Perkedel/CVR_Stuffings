using System;

namespace UnityEditor.ShaderGraph
{
    enum EmissionGIMode
    {
        Disabled,
        Realtime,
        Baked,
    }
}
