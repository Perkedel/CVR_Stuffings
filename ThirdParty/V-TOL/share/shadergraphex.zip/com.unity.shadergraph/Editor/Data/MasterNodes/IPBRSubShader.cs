using System;

namespace UnityEditor.ShaderGraph
{
    interface IPBRSubShader : ISubShader
    {
    }
}
