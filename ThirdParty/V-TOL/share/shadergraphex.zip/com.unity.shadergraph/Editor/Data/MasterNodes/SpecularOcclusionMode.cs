using System;

namespace UnityEditor.ShaderGraph
{
    enum SpecularOcclusionMode
    {
        Off,
        FromAO,
        FromAOAndBentNormal,
        Custom
    }
}
