using System;

namespace UnityEditor.ShaderGraph
{
    enum DistortionMode
    {
        Add,
        Multiply,
        Replace
    }
}
