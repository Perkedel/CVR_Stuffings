using System;

namespace UnityEditor.ShaderGraph
{
    interface IUnlitSubShader : ISubShader
    {}
}
