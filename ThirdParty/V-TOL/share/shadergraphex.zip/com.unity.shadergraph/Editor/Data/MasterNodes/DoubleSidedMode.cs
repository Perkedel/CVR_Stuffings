using System;

namespace UnityEditor.ShaderGraph
{
    enum DoubleSidedMode
    {
        Disabled,
        Enabled,
        FlippedNormals,
        MirroredNormals,
    }
}
