using System;

namespace UnityEditor.ShaderGraph.Internal
{
    public enum UVChannel
    {
        UV0 = 0,
        UV1 = 1,
        UV2 = 2,
        UV3 = 3,
    }
}
