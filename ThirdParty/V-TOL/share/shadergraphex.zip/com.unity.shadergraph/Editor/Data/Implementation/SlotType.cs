namespace UnityEditor.Graphing
{
    enum SlotType
    {
        Input,
        Output
    }
}
