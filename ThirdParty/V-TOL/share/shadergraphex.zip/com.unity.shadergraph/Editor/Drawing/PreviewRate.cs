namespace UnityEditor.ShaderGraph.Drawing
{
    enum PreviewRate
    {
        Full,
        Throttled,
        Off
    }
}
