﻿namespace UnityEditor.ShaderGraph
{
    public enum KeywordDefinition
    {
        ShaderFeature,
        MultiCompile,
        Predefined
    }
}
