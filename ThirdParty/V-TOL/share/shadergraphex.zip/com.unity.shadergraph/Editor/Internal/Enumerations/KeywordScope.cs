﻿namespace UnityEditor.ShaderGraph.Internal
{
    public enum KeywordScope
    {
        Local,
        Global
    }
}
