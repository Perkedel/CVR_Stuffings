﻿namespace UnityEditor.ShaderGraph.Internal
{
    public enum KeywordType
    {
        Boolean,
        Enum
    }
}
