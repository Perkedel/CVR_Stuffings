using System;

namespace UnityEditor.ShaderGraph.Internal
{
    enum NormalDropOffSpace
    {
        Tangent,
        Object,
        World
    }
}
