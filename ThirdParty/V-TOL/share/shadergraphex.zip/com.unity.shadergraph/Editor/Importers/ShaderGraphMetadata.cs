using UnityEngine;

namespace UnityEditor.ShaderGraph
{
    class ShaderGraphMetadata : ScriptableObject
    {
        public string outputNodeTypeName;
    }
}
